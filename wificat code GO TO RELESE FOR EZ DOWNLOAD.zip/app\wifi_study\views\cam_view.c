#include "cam_view.h"
#include "../uart_handler.h"
#include <gui/elements.h>
#include <stdio.h>
#include <string.h>

/* WiFi Camera detector: flags devices whose MAC vendor (OUI) is a known
 * camera/surveillance maker. Heuristic — see README for the honest limits. */

#define ROWS 4
#define ROW_H 11
#define HDR_H 11

typedef struct { WifiStudyApp* app; } CamModel;

static void cam_draw_cb(Canvas* canvas, void* model) {
    CamModel* cm = (CamModel*)model;
    WifiStudyApp* app = cm->app;
    canvas_clear(canvas);

    canvas_draw_box(canvas, 0, 0, 128, HDR_H);
    canvas_set_color(canvas, ColorWhite);
    canvas_set_font(canvas, FontSecondary);
    furi_mutex_acquire(app->data_mutex, FuriWaitForever);
    char hdr[28]; snprintf(hdr, sizeof(hdr), "Camera Detector  %d", app->cam_count);
    canvas_draw_str(canvas, 2, 9, hdr);
    if(app->bw16_ok) canvas_draw_box(canvas, 122, 3, 5, 5);
    canvas_set_color(canvas, ColorBlack);

    if(app->cam_count == 0) {
        canvas_draw_str_aligned(canvas, 64, 30, AlignCenter, AlignCenter,
            app->bw16_ok ? "scanning for cameras..." : "no BW16");
        canvas_draw_str_aligned(canvas, 64, 44, AlignCenter, AlignCenter,
            "(checks MAC vendor)");
    } else {
        int sc = app->cam_scroll;
        if(sc > app->cam_count - ROWS) sc = app->cam_count - ROWS;
        if(sc < 0) sc = 0;
        for(int i=0; i<ROWS && (sc+i)<app->cam_count; i++) {
            int idx = sc + i;
            uint8_t y = HDR_H + (uint8_t)i*ROW_H + 8;
            canvas_draw_str(canvas, 2, y, app->cam_vendor[idx]);
            char r[20]; snprintf(r, sizeof(r), "c%u %s", app->cam_ch[idx],
                                 app->cam_mac[idx] + 9); /* last 8 of mac */
            canvas_draw_str(canvas, 60, y, r);
        }
    }
    furi_mutex_release(app->data_mutex);
}

static bool cam_input_cb(InputEvent* ev, void* context) {
    CamModel* cm = (CamModel*)context;
    WifiStudyApp* app = cm->app;
    if(ev->type != InputTypeShort && ev->type != InputTypeRepeat) return false;
    if(ev->key == InputKeyBack) { uart_send_cmd(app, "CMD,STOP"); return false; }
    furi_mutex_acquire(app->data_mutex, FuriWaitForever);
    if(ev->key == InputKeyUp && app->cam_scroll > 0) app->cam_scroll--;
    if(ev->key == InputKeyDown && app->cam_scroll + ROWS < app->cam_count)
        app->cam_scroll++;
    furi_mutex_release(app->data_mutex);
    return true;
}

static void cam_enter_cb(void* context) {
    CamModel* cm = (CamModel*)context;
    furi_mutex_acquire(cm->app->data_mutex, FuriWaitForever);
    cm->app->cam_count = 0; cm->app->cam_scroll = 0;
    furi_mutex_release(cm->app->data_mutex);
    uart_send_cmd(cm->app, "CMD,CAM");
}

View* cam_view_alloc(WifiStudyApp* app) {
    View* v = view_alloc();
    view_allocate_model(v, ViewModelTypeLocking, sizeof(CamModel));
    CamModel* m = view_get_model(v);
    m->app = app;
    view_commit_model(v, false);
    view_set_context(v, m);
    view_set_draw_callback(v, cam_draw_cb);
    view_set_input_callback(v, cam_input_cb);
    view_set_enter_callback(v, cam_enter_cb);
    return v;
}

void cam_view_free(View* v) { view_free(v); }
